create
    definer = root@localhost procedure sp_getRandom_Value(OUT Rand_Value varchar(10))
BEGIN
  SELECT Rand_Value = Rand_Value
  FROM vw_Function_Base
  ORDER BY RAND()
  LIMIT 1;
END;

